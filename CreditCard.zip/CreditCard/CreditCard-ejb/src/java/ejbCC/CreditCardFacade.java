/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbCC;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Admin
 */
@Stateless
public class CreditCardFacade extends AbstractFacade<CreditCard> implements CreditCardFacadeLocal {
    @PersistenceContext(unitName = "CreditCard-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CreditCardFacade() {
        super(CreditCard.class);
    }
    
}
